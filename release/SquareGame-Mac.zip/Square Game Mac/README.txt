Square Game (Mac)

How to play:
1. Double-click "Play Square Game.command"
2. If macOS warns about an unidentified developer, right-click the file and choose Open.
3. Your default browser will open the game.

This game runs fully offline from local files.
